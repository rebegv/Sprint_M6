package com.example.modulo6.utils;

public enum TipoUsuario {
    Cliente,Profesional,Administrativo;
}
